package com.coursework.weight_tracker_winston_grant;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsNotificationActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1;
    private static final String TAG = "SmsNotificationActivity";
    private TextView smsPermissionMessage;
    private Button requestPermissionButton;
    private Button denyPermissionButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_notification);

        // Initialize UI components
        smsPermissionMessage = findViewById(R.id.sms_permission_message);
        requestPermissionButton = findViewById(R.id.request_permission_button);
        denyPermissionButton = findViewById(R.id.deny_permission_button);

        // Check for SMS permission
        checkSmsPermission();

        // Set click listeners for buttons
        requestPermissionButton.setOnClickListener(v -> requestSmsPermission());
        denyPermissionButton.setOnClickListener(v -> denySmsPermission());
    }

    // Method to check SMS permission
    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted
            smsPermissionMessage.setText(getString(R.string.sms_permission_required));
            requestPermissionButton.setVisibility(View.VISIBLE);
            denyPermissionButton.setVisibility(View.VISIBLE);
        } else {
            // Permission is granted
            smsPermissionMessage.setText(getString(R.string.sms_permission_granted));
            requestPermissionButton.setVisibility(View.GONE);
            denyPermissionButton.setVisibility(View.GONE);
            redirectToMainActivity();
        }
    }

    // Method to request SMS permission
    private void requestSmsPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
    }

    // Method to handle denial of SMS permission
    private void denySmsPermission() {
        smsPermissionMessage.setText(getString(R.string.sms_permission_denied));
        requestPermissionButton.setVisibility(View.GONE);
        denyPermissionButton.setVisibility(View.GONE);
        Toast.makeText(this, getString(R.string.sms_permission_denied), Toast.LENGTH_SHORT).show();
        redirectToMainActivity();
    }

    // Handle the result of permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                smsPermissionMessage.setText(getString(R.string.sms_permission_granted));
                requestPermissionButton.setVisibility(View.GONE);
                denyPermissionButton.setVisibility(View.GONE);
                Toast.makeText(this, getString(R.string.sms_permission_granted), Toast.LENGTH_SHORT).show();
            } else {
                smsPermissionMessage.setText(getString(R.string.sms_permission_denied));
                requestPermissionButton.setVisibility(View.GONE);
                denyPermissionButton.setVisibility(View.GONE);
                Toast.makeText(this, getString(R.string.sms_permission_denied), Toast.LENGTH_SHORT).show();
            }
            redirectToMainActivity();
        }
    }

    // Redirect to MainActivity
    private void redirectToMainActivity() {
        Log.d(TAG, "Redirecting to MainActivity");
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
