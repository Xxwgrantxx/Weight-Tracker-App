package com.coursework.weight_tracker_winston_grant;

public class DataItem {
    private int id;
    private String weight;
    private String date;

    // Constructor to initialize DataItem
    public DataItem(int id, String weight, String date) {
        this.id = id;
        this.weight = weight;
        this.date = date;
    }

    // Getter for id
    public int getId() {
        return id;
    }

    // Getter for weight
    public String getWeight() {
        return weight;
    }

    // Getter for date
    public String getDate() {
        return date;
    }

    // Setter for id
    public void setId(int id) {
        this.id = id;
    }

    // Setter for weight
    public void setWeight(String weight) {
        this.weight = weight;
    }

    // Setter for date
    public void setDate(String date) {
        this.date = date;
    }
}
