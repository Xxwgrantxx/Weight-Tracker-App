package com.coursework.weight_tracker_winston_grant;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weight_tracker.db";
    private static final int DATABASE_VERSION = 2; // Increment the database version

    // Define table and column names
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    private static final String TABLE_WEIGHTS = "weights";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_WEIGHT = "weight";
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_USER = "username";

    private static final String TABLE_GOAL_WEIGHT = "goal_weight_table";
    private static final String COLUMN_GOAL_WEIGHT = "goal_weight";

    // Constructor for DatabaseHelper
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COLUMN_USERNAME + " TEXT PRIMARY KEY, " +
                COLUMN_PASSWORD + " TEXT)";
        db.execSQL(createUsersTable);

        // Create weights table
        String createWeightsTable = "CREATE TABLE " + TABLE_WEIGHTS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_WEIGHT + " TEXT, " +
                COLUMN_DATE + " TEXT, " +
                COLUMN_USER + " TEXT, " +
                "FOREIGN KEY(" + COLUMN_USER + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USERNAME + "))";
        db.execSQL(createWeightsTable);

        // Create goal weight table
        String createGoalWeightTable = "CREATE TABLE " + TABLE_GOAL_WEIGHT + " (" +
                COLUMN_GOAL_WEIGHT + " TEXT, " +
                COLUMN_USER + " TEXT, " +
                "FOREIGN KEY(" + COLUMN_USER + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USERNAME + "))";
        db.execSQL(createGoalWeightTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Handle database upgrade, adding new columns if needed
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE " + TABLE_WEIGHTS + " ADD COLUMN " + COLUMN_USER + " TEXT");
            db.execSQL("ALTER TABLE " + TABLE_GOAL_WEIGHT + " ADD COLUMN " + COLUMN_USER + " TEXT");
        }
    }

    // Method to insert a new user
    public boolean insertUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_USERNAME, username);
        contentValues.put(COLUMN_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, contentValues);
        return result != -1;
    }

    // Method to get a user based on username and password
    public Cursor getUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?", new String[]{username, password});
    }

    // Method to get a user based on username
    public Cursor getUserByUsername(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + " = ?", new String[]{username});
    }

    // Method to insert a new weight entry
    public boolean insertWeight(String username, String weight, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_USER, username);
        contentValues.put(COLUMN_WEIGHT, weight);
        contentValues.put(COLUMN_DATE, date);
        long result = db.insert(TABLE_WEIGHTS, null, contentValues);
        return result != -1;
    }

    // Method to get all weight data for a user
    public Cursor getAllWeightData(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_WEIGHTS + " WHERE " + COLUMN_USER + " = ?", new String[]{username});
    }

    // Method to update a weight entry
    public boolean updateWeight(int id, String weight, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_WEIGHT, weight);
        contentValues.put(COLUMN_DATE, date);
        long result = db.update(TABLE_WEIGHTS, contentValues, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
        return result != -1;
    }

    // Method to delete a weight entry
    public boolean deleteWeight(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(TABLE_WEIGHTS, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
        return result != -1;
    }

    // Method to get the goal weight for a user
    public Cursor getGoalWeight(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_GOAL_WEIGHT + " WHERE " + COLUMN_USER + " = ?", new String[]{username});
    }

    // Method to insert a goal weight
    public boolean insertGoalWeight(String username, String goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_GOAL_WEIGHT, goalWeight);
        contentValues.put(COLUMN_USER, username);
        long result = db.insert(TABLE_GOAL_WEIGHT, null, contentValues);
        return result != -1;
    }
}
