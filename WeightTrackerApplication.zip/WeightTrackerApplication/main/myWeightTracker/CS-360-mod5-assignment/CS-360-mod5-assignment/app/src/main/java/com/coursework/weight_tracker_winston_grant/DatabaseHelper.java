package com.coursework.weight_tracker_winston_grant;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weight_tracker.db";
    private static final int DATABASE_VERSION = 2; // Increment the database version

    //various data that will be stored in database
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    private static final String TABLE_WEIGHTS = "weights";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_WEIGHT = "weight";
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_USER = "username";

    private static final String TABLE_GOAL_WEIGHT = "goal_weight_table";
    private static final String COLUMN_GOAL_WEIGHT = "goal_weight";


    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COLUMN_USERNAME + " TEXT PRIMARY KEY, " +
                COLUMN_PASSWORD + " TEXT)";
        db.execSQL(createUsersTable);

        String createWeightsTable = "CREATE TABLE " + TABLE_WEIGHTS + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_WEIGHT + " TEXT, " +
                COLUMN_DATE + " TEXT, " +
                COLUMN_USER + " TEXT, " +
                "FOREIGN KEY(" + COLUMN_USER + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USERNAME + "))";
        db.execSQL(createWeightsTable);

        String createGoalWeightTable = "CREATE TABLE " + TABLE_GOAL_WEIGHT + " (" +
                COLUMN_GOAL_WEIGHT + " TEXT, " +
                COLUMN_USER + " TEXT, " +
                "FOREIGN KEY(" + COLUMN_USER + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USERNAME + "))";
        db.execSQL(createGoalWeightTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE " + TABLE_WEIGHTS + " ADD COLUMN " + COLUMN_USER + " TEXT");
            db.execSQL("ALTER TABLE " + TABLE_GOAL_WEIGHT + " ADD COLUMN " + COLUMN_USER + " TEXT");
        }
    }

    public boolean insertUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_USERNAME, username);
        contentValues.put(COLUMN_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, contentValues);
        return result != -1;
    }

    public Cursor getUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?", new String[]{username, password});
    }

    public Cursor getUserByUsername(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + " = ?", new String[]{username});
    }

    public boolean insertWeight(String username, String weight, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_USER, username);
        contentValues.put(COLUMN_WEIGHT, weight);
        contentValues.put(COLUMN_DATE, date);
        long result = db.insert(TABLE_WEIGHTS, null, contentValues);
        return result != -1;
    }

    public Cursor getAllWeightData(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_WEIGHTS + " WHERE " + COLUMN_USER + " = ?", new String[]{username});
    }

    public boolean updateWeight(int id, String weight, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_WEIGHT, weight);
        contentValues.put(COLUMN_DATE, date);
        long result = db.update(TABLE_WEIGHTS, contentValues, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
        return result != -1;
    }

    public boolean deleteWeight(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(TABLE_WEIGHTS, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
        return result != -1;
    }

    public Cursor getGoalWeight(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_GOAL_WEIGHT + " WHERE " + COLUMN_USER + " = ?", new String[]{username});
    }

    public boolean insertGoalWeight(String username, String goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_GOAL_WEIGHT, goalWeight);
        contentValues.put(COLUMN_USER, username);
        long result = db.insert(TABLE_GOAL_WEIGHT, null, contentValues);
        return result != -1;
    }

    public boolean updateGoalWeight(String username, String goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_GOAL_WEIGHT, goalWeight);
        long result = db.update(TABLE_GOAL_WEIGHT, contentValues, COLUMN_USER + " = ?", new String[]{username});
        return result != -1;
    }
}
