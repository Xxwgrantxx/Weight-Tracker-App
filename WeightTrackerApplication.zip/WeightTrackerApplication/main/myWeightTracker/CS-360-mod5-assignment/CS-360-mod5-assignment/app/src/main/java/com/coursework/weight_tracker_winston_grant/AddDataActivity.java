package com.coursework.weight_tracker_winston_grant;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat; 
import java.util.Date; 
import java.util.Locale;

public class AddDataActivity extends AppCompatActivity {

    private EditText dataField1;
    private DatabaseHelper databaseHelper;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {    //onCreate method to setup add new weight activity to take user input
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_weight_info);

        databaseHelper = new DatabaseHelper(this);

        dataField1 = findViewById(R.id.data_field_for_weight);
        Button submitDataButton = findViewById(R.id.submit_data);

        // Get the username from the intent
        Intent intent = getIntent();
        username = intent.getStringExtra("username");

        submitDataButton.setOnClickListener(v -> {
            String data1 = dataField1.getText().toString();

            if (!data1.isEmpty()) {
                // Get the current date
                String currentDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

                // Add item to database
                boolean isInserted = databaseHelper.insertWeight(username, data1, currentDate); // Pass the username
                if (isInserted) {
                    Toast.makeText(AddDataActivity.this, "Data added successfully", Toast.LENGTH_SHORT).show();
                    finish(); // Close activity after submission
                } else {
                    Toast.makeText(AddDataActivity.this, "Failed to add data", Toast.LENGTH_SHORT).show();
                }       //error statements if data entry process fails or user doe not enter any data
            } else {
                Toast.makeText(AddDataActivity.this, "Please enter some data", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
