package com.coursework.weight_tracker_winston_grant;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DataGridActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1;
    private DataAdapter dataAdapter;
    private TextView goalWeightText;
    private FloatingActionButton addDataFab;
    private Button setGoalWeightButton;
    private List<DataItem> dataList;
    private DatabaseHelper databaseHelper;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_screen);

        databaseHelper = new DatabaseHelper(this);

        goalWeightText = findViewById(R.id.goal_weight_text);
        goalWeightText.setClickable(false); // Disable click functionality for goal weight text

        ImageView starImage = findViewById(R.id.star_image);
        starImage.setClickable(false); // Disable click functionality for star image

        addDataFab = findViewById(R.id.add_data_fab);
        setGoalWeightButton = findViewById(R.id.set_goal_weight_button);
        dataList = new ArrayList<>();

        RecyclerView dataGrid = findViewById(R.id.data_grid);
        dataGrid.setLayoutManager(new LinearLayoutManager(this)); // One item per row

        addDataFab.setOnClickListener(v -> showAddDataDialog());
        setGoalWeightButton.setOnClickListener(v -> showSetGoalWeightDialog());

        dataAdapter = new DataAdapter(this, dataList);
        dataGrid.setAdapter(dataAdapter);

        // Get the username from the intent
        Intent intent = getIntent();
        username = intent.getStringExtra("username");

        // Load data from database
        loadDataFromDatabase();

        // Check and display the message if no goal weight is set or if it's "GOAL!!"
        checkGoalWeight();
    }

    private void loadDataFromDatabase() {
        dataList.clear(); // Clear the existing data
        Cursor cursor = databaseHelper.getAllWeightData(username); // Pass the username
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String weight = cursor.getString(cursor.getColumnIndexOrThrow("weight"));
                String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));
                dataList.add(new DataItem(id, weight, date));
            } while (cursor.moveToNext());
            cursor.close();
        }

        Cursor goalCursor = databaseHelper.getGoalWeight(username); // Pass the username
        if (goalCursor != null && goalCursor.moveToFirst()) {
            String goalWeight = goalCursor.getString(goalCursor.getColumnIndexOrThrow("goal_weight"));
            goalWeightText.setText(goalWeight);
            setGoalWeightButton.setText("Edit Goal Weight");
            goalCursor.close();
        }

        dataAdapter.notifyDataSetChanged();
    }


    private void checkGoalWeight() {
        String goalWeight = goalWeightText.getText().toString();
        if (goalWeight.isEmpty() || goalWeight.equals("GOAL!!")) {
            setGoalWeightButton.setVisibility(View.VISIBLE);
            addDataFab.setEnabled(false); // Disable FAB if no goal weight is set
        } else {
            setGoalWeightButton.setVisibility(View.VISIBLE); // Ensure button is visible
            addDataFab.setEnabled(true); // Enable FAB if goal weight is set
        }
    }

    private void showAddDataDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = this.getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.activity_add_new_weight_info, null);
        builder.setView(dialogView);

        EditText inputData = dialogView.findViewById(R.id.data_field_for_weight);
        inputData.setInputType(InputType.TYPE_CLASS_NUMBER); // Restrict to numeric input
        Button addButton = dialogView.findViewById(R.id.submit_data);

        AlertDialog alertDialog = builder.create();

        addButton.setOnClickListener(v -> {
            String data = inputData.getText().toString();
            if (!data.isEmpty()) {
                try {
                    int weight = Integer.parseInt(data);
                    if (weight > 999 || weight < 1 || data.length() > 3) {
                        Toast.makeText(DataGridActivity.this, "Weight must be a positive integer no larger than 999 and no more than 3 digits", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    // Get the current date
                    String currentDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

                    // Add item to database
                    boolean isInserted = databaseHelper.insertWeight(username, data, currentDate); // Pass the username
                    if (isInserted) {
                        // Add item to data list and notify adapter
                        Cursor cursor = databaseHelper.getAllWeightData(username); // Pass the username
                        if (cursor != null && cursor.moveToLast()) {
                            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                            dataList.add(new DataItem(id, data, currentDate));
                            dataAdapter.notifyItemInserted(dataList.size() - 1);
                            cursor.close();
                        }
                    } else {
                        Toast.makeText(DataGridActivity.this, "Failed to add data", Toast.LENGTH_SHORT).show();
                    }

                    // Check if data entered equals goal weight and send notification if they are equal
                    if (data.equals(goalWeightText.getText().toString())) {
                        sendSmsNotification(data);
                    }

                    alertDialog.dismiss();
                } catch (NumberFormatException e) {
                    Toast.makeText(DataGridActivity.this, "Invalid weight value", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(DataGridActivity.this, "Please enter some data", Toast.LENGTH_SHORT).show();
            }
        });

        alertDialog.show();
    }

    private void showSetGoalWeightDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Set Goal Weight");

        final EditText input = new EditText(this);
        input.setHint("Enter goal weight");
        input.setSingleLine(true); // Prevent entering new lines
        input.setInputType(InputType.TYPE_CLASS_NUMBER); // Restrict to numeric input
        builder.setView(input);

        builder.setPositiveButton("Set", (dialog, which) -> {
            String goalWeight = input.getText().toString();
            try {
                int weight = Integer.parseInt(goalWeight);
                if (weight > 999 || weight < 1 || goalWeight.length() > 3) {
                    Toast.makeText(DataGridActivity.this, "Goal weight must be a positive integer no larger than 999 and no more than 3 digits", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean isInserted = databaseHelper.insertGoalWeight(username, goalWeight); // Pass the username
                if (isInserted) {
                    goalWeightText.setText(goalWeight);
                    setGoalWeightButton.setText("Edit Goal Weight");
                    Toast.makeText(DataGridActivity.this, "Goal weight set successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(DataGridActivity.this, "Failed to set goal weight", Toast.LENGTH_SHORT).show();
                }
                checkGoalWeight(); // Update the message visibility and FAB state after setting goal weight
            } catch (NumberFormatException e) {
                Toast.makeText(DataGridActivity.this, "Invalid goal weight value", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }

    private void sendSmsNotification(String data) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            String phoneNumber = "1234567890"; // Will replace with way to get the actual phone number
            String message = "Congratulations! You have reached your goal weight: " + data + ".";
            SmsManager smsManager = getSystemService(SmsManager.class);
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "Notification sent", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                String goalWeight = goalWeightText.getText().toString();
                sendSmsNotification(goalWeight);
            } else {
                Toast.makeText(this, "SMS permission denied. Notifications will not be sent.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
