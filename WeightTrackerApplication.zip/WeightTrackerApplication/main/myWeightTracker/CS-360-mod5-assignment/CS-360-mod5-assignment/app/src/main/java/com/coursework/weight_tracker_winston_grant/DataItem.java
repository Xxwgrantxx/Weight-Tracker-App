package com.coursework.weight_tracker_winston_grant;

public class DataItem {
    private int id;
    private String weight;
    private String date;

    public DataItem(int id, String weight, String date) {
        this.id = id;
        this.weight = weight;
        this.date = date;
    }

    public int getId() {
        return id;
    }

    public String getWeight() {
        return weight;
    }

    public String getDate() {
        return date;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
