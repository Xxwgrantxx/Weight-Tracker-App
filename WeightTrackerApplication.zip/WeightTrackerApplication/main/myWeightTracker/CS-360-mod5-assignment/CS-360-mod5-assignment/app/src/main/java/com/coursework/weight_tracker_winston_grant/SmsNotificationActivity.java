package com.coursework.weight_tracker_winston_grant;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsNotificationActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1;
    private static final String TAG = "SmsNotificationActivity";
    private TextView smsPermissionMessage;
    private Button requestPermissionButton;
    private Button denyPermissionButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_notification);

        smsPermissionMessage = findViewById(R.id.sms_permission_message);
        requestPermissionButton = findViewById(R.id.request_permission_button);
        denyPermissionButton = findViewById(R.id.deny_permission_button);

        // Check for SMS permission
        checkSmsPermission();

        requestPermissionButton.setOnClickListener(v -> requestSmsPermission());
        denyPermissionButton.setOnClickListener(v -> denySmsPermission());
    }

    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted
            smsPermissionMessage.setText("This app requires permission to send SMS notifications.");
            requestPermissionButton.setVisibility(View.VISIBLE);
            denyPermissionButton.setVisibility(View.VISIBLE);
        } else {
            // Permission is granted
            smsPermissionMessage.setText("SMS permission granted. You can now receive SMS notifications.");
            requestPermissionButton.setVisibility(View.GONE);
            denyPermissionButton.setVisibility(View.GONE);
            redirectToMainActivity();
        }
    }

    private void requestSmsPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
    }

    private void denySmsPermission() {
        smsPermissionMessage.setText("SMS permission denied. You cannot receive SMS notifications.");
        requestPermissionButton.setVisibility(View.GONE);
        denyPermissionButton.setVisibility(View.GONE);
        Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
        redirectToMainActivity();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                smsPermissionMessage.setText("SMS permission granted. You can now receive SMS notifications.");
                requestPermissionButton.setVisibility(View.GONE);
                denyPermissionButton.setVisibility(View.GONE);
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                smsPermissionMessage.setText("SMS permission denied. You cannot receive SMS notifications.");
                requestPermissionButton.setVisibility(View.GONE);
                denyPermissionButton.setVisibility(View.GONE);
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
            redirectToMainActivity();
        }
    }

    private void redirectToMainActivity() {
        Log.d(TAG, "Redirecting to MainActivity");
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
