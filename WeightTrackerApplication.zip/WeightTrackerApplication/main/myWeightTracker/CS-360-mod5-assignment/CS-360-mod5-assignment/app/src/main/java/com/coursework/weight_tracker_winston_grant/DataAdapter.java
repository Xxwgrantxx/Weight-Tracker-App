package com.coursework.weight_tracker_winston_grant;

import android.app.AlertDialog;
import android.content.Context;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.ViewHolder> {
    private final List<DataItem> dataList;
    private final DatabaseHelper databaseHelper;
    private final Context context;

    public DataAdapter(Context context, List<DataItem> dataList) {
        this.dataList = dataList;
        this.databaseHelper = new DatabaseHelper(context);
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.data_item_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        DataItem dataItem = dataList.get(position);
        holder.textViewData.setText(dataItem.getWeight());
        holder.textViewDate.setText(dataItem.getDate());
        holder.deleteButton.setOnClickListener(v -> removeItem(position));
        holder.itemView.setOnClickListener(v -> updateItem(position));
    }

    private void removeItem(int position) {
        DataItem dataItem = dataList.get(position);
        boolean isDeleted = databaseHelper.deleteWeight(dataItem.getId());
        if (isDeleted) {
            dataList.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, dataList.size());
            Toast.makeText(context, "Weight deleted successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(context, "Failed to delete weight", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateItem(int position) {
        DataItem dataItem = dataList.get(position);
        // Show dialog to update item
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Update Weight and Date");

        final EditText inputWeight = new EditText(context);
        inputWeight.setHint("Enter new weight");
        inputWeight.setSingleLine(true);
        inputWeight.setInputType(InputType.TYPE_CLASS_NUMBER);
        inputWeight.setText(dataItem.getWeight());

        final EditText inputDate = new EditText(context);
        inputDate.setHint("Enter new date (yyyy-MM-dd)");
        inputDate.setSingleLine(true);
        inputDate.setInputType(InputType.TYPE_CLASS_DATETIME);
        inputDate.setText(dataItem.getDate());

        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.addView(inputWeight);
        layout.addView(inputDate);
        builder.setView(layout);

        builder.setPositiveButton("Update", (dialog, which) -> {
            String newWeight = inputWeight.getText().toString();
            String newDate = inputDate.getText().toString();
            boolean isUpdated = databaseHelper.updateWeight(dataItem.getId(), newWeight, newDate);
            if (isUpdated) {
                dataItem.setWeight(newWeight);
                dataItem.setDate(newDate);
                notifyItemChanged(position);
                Toast.makeText(context, "Weight and date updated successfully", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(context, "Failed to update weight and date", Toast.LENGTH_SHORT).show();
            }
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textViewData;
        public TextView textViewDate;
        public ImageButton deleteButton;

        public ViewHolder(View itemView) {
            super(itemView);
            textViewData = itemView.findViewById(R.id.text_view_data);
            textViewDate = itemView.findViewById(R.id.text_view_date);
            deleteButton = itemView.findViewById(R.id.button_delete);
        }
    }
}
