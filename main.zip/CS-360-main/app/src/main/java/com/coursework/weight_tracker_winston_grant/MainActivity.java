package com.coursework.weight_tracker_winston_grant;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "MyPrefsFile";
    private static final String FIRST_LOGIN_KEY = "firstLogin";
    private static final String TAG = "MainActivity";
    private EditText usernameEditText;
    private EditText passwordEditText;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entry_screen);

        // Initialize DatabaseHelper
        databaseHelper = new DatabaseHelper(this);

        // Initialize UI components
        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        Button submitButton = findViewById(R.id.login);
        Button createAccountButton = findViewById(R.id.create_account);

        // Check if it's the user's first login
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        boolean firstLogin = settings.getBoolean(FIRST_LOGIN_KEY, true);
        Log.d(TAG, "First login: " + firstLogin);

        if (firstLogin) {
            // Update the first login flag
            SharedPreferences.Editor editor = settings.edit();
            editor.putBoolean(FIRST_LOGIN_KEY, false);
            editor.apply();

            // Redirect to SmsNotificationActivity to request permission
            Intent intent = new Intent(MainActivity.this, SmsNotificationActivity.class);
            startActivity(intent);
            finish();
        }

        // Set the submit button click listener
        submitButton.setOnClickListener(v -> {
            try {
                // Get login info
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                Log.d(TAG, "Username: " + username);
                Log.d(TAG, "Password: " + password);

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
                } else if (isValidCredentials(username, password)) {
                    // Navigate to DataGridActivity after successful login
                    Intent intent = new Intent(MainActivity.this, DataGridActivity.class);
                    intent.putExtra("username", username); // Pass the username
                    startActivity(intent);
                } else {
                    // Handle invalid credentials
                    Toast.makeText(MainActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Log.e(TAG, "Error during login", e);
                Toast.makeText(MainActivity.this, "An error occurred during login", Toast.LENGTH_SHORT).show();
            }
        });

        // Set the create account button click listener
        createAccountButton.setOnClickListener(v -> {
            try {
                // Get account creation info
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                Log.d(TAG, "Username: " + username);
                Log.d(TAG, "Password: " + password);

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
                } else if (isUsernameTaken(username)) {
                    // Handle username already taken
                    Toast.makeText(MainActivity.this, "Username is already taken", Toast.LENGTH_SHORT).show();
                } else {
                    // Create new account
                    boolean isInserted = databaseHelper.insertUser(username, password);
                    if (isInserted) {
                        Toast.makeText(MainActivity.this, "Account created successfully", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(MainActivity.this, "Failed to create account", Toast.LENGTH_SHORT).show();
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "Error during account creation", e);
                Toast.makeText(MainActivity.this, "An error occurred during account creation", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Validation for username and password
    private boolean isValidCredentials(String username, String password) {
        Cursor cursor = databaseHelper.getUser(username, password);
        boolean isValid = cursor.getCount() > 0;
        cursor.close();
        return isValid;
    }

    // Check if username is already taken
    private boolean isUsernameTaken(String username) {
        Cursor cursor = databaseHelper.getUserByUsername(username);
        boolean isTaken = cursor.getCount() > 0;
        cursor.close();
        return isTaken;
    }
}

